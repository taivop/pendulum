package esimene;

import ij.gui.Roi;

public class RoiAndNumber {
	Roi r;
	int number;
	
	RoiAndNumber(Roi r, int number) {
		this.r = r;
		this.number = number;
	}
}